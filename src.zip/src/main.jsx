import React from 'react'
import ReactDOM from 'react-dom/client'
import Nav from './Components/Nav'
import Left from './Components/Left'
import Right from './Components/Right'
import Exam from './Components/Exam'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Nav />
    <Left />
    <Right />
    <Exam />
  </React.StrictMode>,
)
