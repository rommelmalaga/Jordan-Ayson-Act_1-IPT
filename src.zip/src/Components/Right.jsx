import '../App.css'
import Nav from './Nav'

function Right() {
    return (
        <div className='right'>
                <h4>Top Sidebar</h4>
    
        </div>
    )
}

export default Right;