import '../App.css'

function Exam() {
    return(
        <div className='main'>
            <h3>This is my content</h3>
        </div>
    )
}
export default Exam;