import '../App.css';

function Left() {
    return (
        <div  className='left'>
            <div className='top'>
                <h4>Top Container</h4>
            </div>
            <div className='below'>
                <h4>Below Container</h4>
            </div>
        </div> 

        
    )
}

export default Left;